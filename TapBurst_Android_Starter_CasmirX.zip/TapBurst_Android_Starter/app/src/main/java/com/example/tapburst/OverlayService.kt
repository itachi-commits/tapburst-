package com.example.tapburst

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var panel: View? = null
    private var params: WindowManager.LayoutParams? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 8, 12, 8)
            setBackgroundColor(Color.argb(230, 25, 28, 38))
        }
        val title = TextView(this).apply {
            text = "⚡ TapBurst"
            textSize = 16f
            setTextColor(Color.WHITE)
        }
        val status = TextView(this).apply {
            text = "Hold VOL+ to test*"
            textSize = 12f
            setTextColor(Color.LTGRAY)
        }
        val toggle = Button(this).apply {
            text = "Start / Stop"
            setOnClickListener {
                val svc = TapAccessibilityService.instance
                if (svc == null) {
                    Toast.makeText(this@OverlayService, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
                } else {
                    // Button is a manual toggle for testing; second press stops it.
                    if (isRunning) {
                        svc.stopRepeating()
                        isRunning = false
                        status.text = "Stopped"
                    } else {
                        svc.startRepeating()
                        isRunning = true
                        status.text = "Repeating (tap Stop)"
                    }
                }
            }
        }
        val close = Button(this).apply {
            text = "×"
            setOnClickListener { stopSelf() }
        }
        layout.addView(title)
        layout.addView(status)
        layout.addView(toggle)
        layout.addView(close)

        layout.setOnTouchListener(object : View.OnTouchListener {
            var initialX = 0
            var initialY = 0
            var startX = 0f
            var startY = 0f
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val p = params ?: return false
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = p.x; initialY = p.y
                        startX = event.rawX; startY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        p.x = initialX + (event.rawX - startX).toInt()
                        p.y = initialY + (event.rawY - startY).toInt()
                        wm.updateViewLayout(layout, p)
                        return true
                    }
                }
                return false
            }
        })

        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 20; y = 180
        }
        panel = layout
        wm.addView(layout, params)
    }

    private var isRunning = false

    override fun onDestroy() {
        TapAccessibilityService.instance?.stopRepeating()
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
