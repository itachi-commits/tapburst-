package com.example.tapburst

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private lateinit var speedLabel: TextView
    private var interval = 150L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(Color.rgb(17, 19, 26))
        }
        fun label(text: String, size: Float = 16f) = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 8)
        }
        root.addView(label("⚡ TapBurst", 28f))
        root.addView(label("CODM touch-assistant prototype", 14f))
        root.addView(label("Tap interval:"))
        speedLabel = label("$interval ms", 20f)
        root.addView(speedLabel)

        val slider = SeekBar(this).apply {
            max = 450
            progress = 150
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    interval = (50 + progress).toLong()
                    speedLabel.text = "$interval ms"
                    getSharedPreferences("tapburst", MODE_PRIVATE).edit()
                        .putLong("interval", interval).apply()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(slider)

        root.addView(label("Tap target coordinates (screen pixels)"))
        val xInput = EditText(this).apply {
            hint = "X coordinate (e.g. 900)"
            setSingleLine(true)
            inputType = 2
            setText(getSharedPreferences("tapburst", MODE_PRIVATE).getInt("tap_x", 900).toString())
        }
        val yInput = EditText(this).apply {
            hint = "Y coordinate (e.g. 1700)"
            setSingleLine(true)
            inputType = 2
            setText(getSharedPreferences("tapburst", MODE_PRIVATE).getInt("tap_y", 1700).toString())
        }
        root.addView(xInput)
        root.addView(yInput)

        val save = Button(this).apply {
            text = "Save target"
            setOnClickListener {
                val x = xInput.text.toString().toIntOrNull()
                val y = yInput.text.toString().toIntOrNull()
                if (x == null || y == null) {
                    Toast.makeText(this@MainActivity, "Enter valid coordinates", Toast.LENGTH_SHORT).show()
                } else {
                    getSharedPreferences("tapburst", MODE_PRIVATE).edit()
                        .putInt("tap_x", x).putInt("tap_y", y).apply()
                    Toast.makeText(this@MainActivity, "Target saved", Toast.LENGTH_SHORT).show()
                }
            }
        }
        root.addView(save)

        root.addView(Button(this).apply {
            text = "Grant overlay permission"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")))
            }
        })
        root.addView(Button(this).apply {
            text = "Enable TapBurst accessibility service"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text = "Show floating control"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Grant overlay permission first", Toast.LENGTH_LONG).show()
                } else {
                    startService(Intent(this@MainActivity, OverlayService::class.java))
                    Toast.makeText(this@MainActivity, "Floating control started", Toast.LENGTH_SHORT).show()
                }
            }
        })
        root.addView(label(
            "Prototype note: Android/game compatibility and volume-key hold detection are not guaranteed. " +
            "Use only where permitted by the game rules.", 13f
        ))
        // Subtle creator credit, intentionally kept small and low-key.
        root.addView(label("TapBurst v1.0  ·  crafted by CasmirX", 11f).apply {
            setTextColor(Color.rgb(145, 149, 160))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 2)
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }
}
