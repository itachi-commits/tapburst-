package com.example.tapburst

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class TapAccessibilityService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var repeating = false
    private var volumeHeld = false

    override fun onServiceConnected() {
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopRepeating() }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        // Experimental only: Android/device policy may not deliver volume key events here.
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_UP) return false
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            volumeHeld = true
            startRepeating()
        } else if (event.action == KeyEvent.ACTION_UP) {
            volumeHeld = false
            stopRepeating()
        }
        return false // Do not consume the volume key; let system volume behaviour continue.
    }

    fun startRepeating() {
        if (repeating) return
        repeating = true
        tick()
    }

    fun stopRepeating() {
        repeating = false
        handler.removeCallbacksAndMessages(null)
    }

    private fun tick() {
        if (!repeating) return
        val prefs = getSharedPreferences("tapburst", MODE_PRIVATE)
        val x = prefs.getInt("tap_x", 900).toFloat()
        val y = prefs.getInt("tap_y", 1700).toFloat()
        val interval = prefs.getLong("interval", 150L).coerceIn(50L, 500L)
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 35))
            .build()
        dispatchGesture(gesture, null, null)
        handler.postDelayed({ tick() }, interval)
    }

    override fun onDestroy() {
        stopRepeating()
        if (instance === this) instance = null
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: TapAccessibilityService? = null
            private set
    }
}
