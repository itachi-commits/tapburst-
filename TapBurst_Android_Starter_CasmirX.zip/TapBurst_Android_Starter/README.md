# TapBurst Android Starter (prototype)

This is a starter Android Studio project for a floating touch-assistant prototype.

## Important limitations
- It is **not a finished, tested APK**.
- Volume-key hold detection through AccessibilityService is experimental and may not work on the Samsung S10 or while CODM is foregrounded. Android/device restrictions can prevent it.
- The floating control includes a manual start/stop test control. It is not a polished production UI.
- Repeated accessibility gestures may not be accepted by CODM, and automated gameplay input may conflict with the game's rules. Check the current CODM policy before using it.
- The configured target uses raw screen coordinates; screen rotation, display scaling, HUD layout, and safe areas can affect accuracy.
- This starter has not been compiled or tested on a physical device.

## Open in Android Studio
1. Install Android Studio on Windows 11.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `TapBurst_Android_Starter` folder.
4. Allow Gradle to sync and install any requested Android SDK components.
5. Build > Build APK(s). The APK output should be under `app/build/outputs/apk/debug/` if the build succeeds.

## First launch
1. Open TapBurst.
2. Grant overlay permission.
3. Open Accessibility settings and enable "TapBurst gesture service".
4. Return to TapBurst and choose "Show floating control".
5. Test only outside CODM first.

## Project structure
- `MainActivity.kt`: settings and permission shortcuts
- `OverlayService.kt`: draggable floating panel and manual start/stop
- `TapAccessibilityService.kt`: accessibility gesture dispatch and experimental volume-key listener


Branding: the main screen includes a small, subtle “TapBurst v1.0 · crafted by CasmirX” credit at the bottom. The app name remains TapBurst.
